package com.nau.view;

import java.util.Scanner;

import com.nau.dao.AdminDaoInterface;
import com.nau.dao.LoginDao;
import com.nau.model.Login;
import com.nau.model.LoginType;

public class AdminView {

	private Scanner input = new Scanner(System.in);
	private AdminDaoInterface loginDao = new LoginDao();

	public AdminView() {
		int n;
		do {
		System.out.println("Welcome to Admin View!!!!!!!!!");
		System.out.println("Press \n 1: Add Users \n 2: Delete User \n 3: Update User \n 4: Display All \n 5:Display Employee by city\n 6: LogOut \n Enter Your Choise:");
		n=input.nextInt();
		switch(n) {
		case 1:
			viewPanel();
			break;
		case 2:
			System.out.println("Enter User Id To be deleted:");
			int id=input.nextInt();
			loginDao.deleteLogin(id);
			break;
		case 3:
			System.out.println("Enter User Id To be Updated:");
			int Id=input.nextInt();
			loginDao.updateAdminLogin(Id);
			break;
		case 4:
			loginDao.displayAllLogin();
			break;
		case 5:
			loginDao.displayEmployeeByCity();
			break;
		case 6:
			loginDao.displayEmployeeByID();
			break;
		case 7:
			System.out.println("LogOut Sucessfully!!!");
			System.exit(0);
			
		default:
			System.out.println("Please Enter Correct Choise!!!!!!!!!");
		}
		}while(n!=5);
		
	}

	private void viewPanel() {
		//System.out.println("1. Add User");
		System.out.println("Enter User ID");
		String userId = input.next();
		System.out.println("Enter Password");
		String password = input.next();
		System.out.println("Enter Type :  USER | ADMIN | MANAGER "  );
		String type = input.next();
		type = type.toUpperCase();
		LoginType loginType = LoginType.USER;
		switch (type) {
		case "USER": {
			loginType = LoginType.USER;
			break;
		}
		case "ADMIN": {
			loginType = LoginType.ADMIN;
			break;
		}
		case "MANAGER": {
			loginType = LoginType.MANAGER;
			break;
		}
		default: {
			System.out.println("PROPER TYPE NOT GIVEN");
		}
		}

		System.out.println("Enter First Name : ");
		String fName = input.next();
		System.out.println("Enter Lass Name");
		String lName = input.next();
		System.out.println("Enter city");
		String city = input.next();
		Login login = new Login(Integer.valueOf(userId), password, loginType, fName, lName, city);
		loginDao.addLogin(login);
		System.out.println("Saved");

	}

}
