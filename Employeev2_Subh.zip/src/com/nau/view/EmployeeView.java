package com.nau.view;

import java.util.Scanner;

import com.nau.dao.AdminDaoInterface;
import com.nau.dao.EmployeeDaoInterface;
import com.nau.dao.LoginDao;

public class EmployeeView {
	
	private Scanner input = new Scanner(System.in);
	private EmployeeDaoInterface loginDao  = new LoginDao();
	
	public EmployeeView() {};
	
	public EmployeeView(String userId) {
		int n;
		do {
		System.out.println(" Welcome to EmployeeView !!!! \n Enter Your Choise as \n 1 : View Your  Details \n 2: Update Your Details \n 3: LogOut \n Enter Your Choise:");
		n=input.nextInt();
		switch(n) {
		case 1:
			loginDao.viewOwnDetails(Integer.valueOf(userId));
			break;
		case 2:
			loginDao.updateUserLogin(Integer.valueOf(userId));
			break;
		case 3:
			System.out.println("LogOut Succesfully!!!!!!!!");
			System.exit(0);
		default:
			System.out.println("Please Enter Correct Choise!!!!!");
		}
		}while(n!=3);
	}
	
	

}
