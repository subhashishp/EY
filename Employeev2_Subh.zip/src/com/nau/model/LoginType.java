package com.nau.model;

public enum LoginType {
	
	USER,ADMIN,MANAGER

}
