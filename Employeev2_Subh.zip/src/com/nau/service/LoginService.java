package com.nau.service;

import java.util.Optional;
import java.util.logging.Logger;

import com.nau.dao.LoginDao;
import com.nau.model.Login;
import com.nau.model.LoginType;
import com.nau.view.AdminView;
import com.nau.view.EmployeeView;

public class LoginService {
	private static final Logger log = Logger.getLogger(LoginService.class.getName());

	private LoginDao loginDao = new LoginDao();

	public LoginService() {

	}

	public String verifyUser(String userId, String password) {
		log.info("User Id : " + userId + " and  password : " + password);
		String pattern = "[0-9]{3,3}";// RegExpression
		log.info("" + userId.matches(pattern));
		String message = "";
		if (userId.matches(pattern)) {
			Optional<Login> optional = loginDao.getUserById(Integer.valueOf(userId));
			if (optional.isPresent()) {
				Login login = optional.get();
				System.out.println(login);// log
				if (login.getPassword().equals(password)) {
					if(login.getType()==LoginType.USER) {
						message = "Welcome " + login.getfName() + " " + login.getlName();
						new EmployeeView(userId);
					}else {
						message = "Welcome " + login.getfName() + " " + login.getlName();
						new AdminView();
					}
				}else {
					message =  "Password Invalid";
				}
			} else {
				message = "ID not Found";
			}
		} else {
			message = ("Please Enter only 3 digit Id");
		}
		return  message;
//		if (userId.matches(pattern)) {
//			Login login = loginDao.getUserById(Integer.valueOf(userId));
//			if(login==null) {
//				System.out.println("id not found");
//			}else {
//				System.out.println(login.getPassword());
//			}
//			
//		}
	}

}
