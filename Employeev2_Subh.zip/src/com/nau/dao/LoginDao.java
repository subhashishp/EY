package com.nau.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashSet;
import java.util.Optional;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;

import com.nau.model.Login;
import com.nau.model.LoginType;
import com.nau.view.LoginView;

public class LoginDao implements AdminDaoInterface,EmployeeDaoInterface {
	Scanner input=new Scanner(System.in);
	private static Set<Login> logins = new HashSet<>();
	static {
		File file = new File("logindata.ser");
		if (file.exists()) {
			try (FileInputStream fileInputStream = new FileInputStream(file);
					ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream)) {
				logins = (HashSet<Login>)(objectInputStream.readObject());
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		} else {
			logins.add(new Login(111, "u111", LoginType.USER, "Naushad", "Akthar","Kolkata"));
			logins.add(new Login(112, "u111", LoginType.USER, "Sudipta", "Sasmal","Kolkata"));
			logins.add(new Login(222, "a222", LoginType.ADMIN, "RK", "Prgyajit","Mumbai"));
			logins.add(new Login(221, "a221", LoginType.ADMIN, "Priyanka", "Roy","Pune"));
		}
	}

	@Override
	public void addLogin(Login login) {
		logins.add(login);
	}

	@Override
	public void deleteLogin(int userId) {
		//Set<Login> login=(Set<Login>) logins.stream().filter(login->login.getUserId()==userId).collect(Collectors.toList());
		//logins.remove(login);
		for(Login log:logins)
		{
			if(log.getUserId()==userId)
			{
				logins.remove(log);
				break;
			}
		}
		System.out.println("Employee Deleted Succesfully!!!!");
		
	}

	@Override
	public void updateUserLogin(int userId) {
		for(Login log:logins)
		{
			if(log.getUserId()==userId)
			{
				System.out.println("Enter New First Name:");
				String fname=input.next();
				System.out.println("Enter New Last Name:");
				String lname=input.next();
				System.out.println("Enter New Password:");
				String password=input.next();
				log.setfName(fname);
				log.setlName(lname);
				log.setPassword(password);
			}
		}
		System.out.println("Updated Successfully!!!!!!!!!!");

	}

	@Override
	public void updateAdminLogin(int ID) {
		for(Login log:logins)
		{
			if(log.getUserId()==ID) {
				System.out.println("Enter New Employee Type of User Id:"+log.getUserId());
				String type = input.next();
				type = type.toUpperCase();
				LoginType loginType = LoginType.USER;
				switch (type) {
				case "USER": {
					loginType = LoginType.USER;
					break;
				}
				case "ADMIN": {
					loginType = LoginType.ADMIN;
					break;
				}
				case "MANAGER": {
					loginType = LoginType.MANAGER;
					break;
				}
				default: {
					System.out.println("PROPER TYPE NOT GIVEN");
				}
				}
				log.setType(loginType);
			}
		}
	}
	@Override
	public void viewOwnDetails(int userId)
	{
		for(Login log:logins)
		{
			if(log.getUserId()==userId) {
				System.out.println("Your Details is as Folow:");
				System.out.println("First Name: "+log.getfName()+" || Last Name:"+log.getlName()+" || Type:"+log.getType()+"|| User ID:"+log.getUserId());
			}
		}
	}
	@Override
	public void displayAllLogin()
	{
		System.out.println("UserId \t\t Type \t\t FName \t\t LName \t\t ");
		System.out.println("=======================================================================");
		for(Login log:logins)
		{
			System.out.println(log.getUserId()+"\t\t"+log.getType()+"\t\t"+log.getfName()+"\t\t"+log.getlName());
		}
	}
	
	@Override
	public void displayEmployeeByCity()
	{
		System.out.println("Enter name of city");
		String city = input.nextLine();
		for(Login emp : logins)
		{
			//System.out.println(emp);
			if(emp.getCity().equals(city))
			{
				System.out.println(emp.getfName() + " " + emp.getlName());
			}
		}
		
	}
	
	@Override
	public void displayEmployeeByID()
	{
		System.out.println("Enter name of city");
		Integer ID = input.nextInt();
		for(Login emp : logins)
		{
			//System.out.println(emp);
			if(emp.getUserId() == ID)
			{
				System.out.println(emp.getfName() + " " + emp.getlName());
			}
		}
		
	}

	@Override
	public Optional<Login> getUserById(Integer userId) {
		Optional<Login> optional = logins.stream().filter((login) -> login.getUserId().equals(userId)).findFirst();
		return optional;
	}

	
	public static void saveLogin() {
		try (FileOutputStream fileOutputStream = new FileOutputStream("logindata.ser");
				ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream)) {
			objectOutputStream.writeObject(logins);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

//	public Login getUserById(Integer userId) {
//		
//		for(Login login : logins) {
//			if(login.getUserId().equals(userId)) {
//				return login;
//			}
//		}
//		return null;
//		
//	}
}
