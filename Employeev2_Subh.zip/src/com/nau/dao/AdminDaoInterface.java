package com.nau.dao;

import java.util.Optional;

import com.nau.model.Login;

public interface AdminDaoInterface{
	void addLogin(Login login);
	void deleteLogin(int userId);
	void updateAdminLogin(int ID);
	void displayAllLogin();
	void displayEmployeeByCity();
	Optional<Login> getUserById(Integer userId);
	void displayEmployeeByID();
}
