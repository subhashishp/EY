package com.nau.dao;

public interface EmployeeDaoInterface {
	void updateUserLogin(int userId);
	void viewOwnDetails(int userId);	
}

