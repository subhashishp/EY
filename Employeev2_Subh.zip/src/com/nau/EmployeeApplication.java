package com.nau;

import java.util.logging.Logger;

import com.nau.dao.LoginDao;
import com.nau.view.LoginView;

public class EmployeeApplication {

	private static final Logger log = Logger.getLogger(EmployeeApplication.class.getName());

	public static void main(String[] args) {
		log.info("Inside Main Method");

		Thread thread = new Thread(() -> {
			LoginDao.saveLogin();
			log.info("Exiting via Shutdown Hook");
		});
		Runtime.getRuntime().addShutdownHook(thread);
		new LoginView();
		log.info("Exiting Main App");
	}
}
