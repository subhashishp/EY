package com.ey.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ey.model.UserModel;
import com.ey.service.LoginService;

@RestController
@RequestMapping("login")
@CrossOrigin
public class LoginController {

	@Autowired
	private LoginService loginService;
	
	@PostMapping	//takes username and password from user and checks it with database
	public Integer checkCredentials(@RequestBody UserModel userData)
	{
		System.out.println("before pass " + userData.getUserPassword());
		Boolean answer = loginService.checkUsernameandPassword(userData);
		
		System.out.println(answer); 
		if(answer)
		{
			return userData.getCustomerID();
		}
		
		return -1;
	}
	
}
