package com.ey.service;

import com.ey.model.UserModel;

public interface LoginService {

	Boolean checkUsernameandPassword(UserModel userData);
}
