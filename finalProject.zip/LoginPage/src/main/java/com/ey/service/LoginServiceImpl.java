package com.ey.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.dao.LoginDAO;
import com.ey.entity.UserEntity;
import com.ey.model.UserModel;

@Service
public class LoginServiceImpl implements LoginService{

	@Autowired
	private LoginDAO dao; 
	
	@Override
	public Boolean checkUsernameandPassword(UserModel userData) {
		
		
		UserModel tempModel = dao.checkUsernameandPassword(userData);
		
		// do password check
		
		//tempModel contains database data
		//userData contains the data from user (controller)
		System.out.println("tempModel " + tempModel.getUserPassword() );
		System.out.println("userData " + userData.getUserPassword() );
		if(tempModel != null)
		{
			if(tempModel.getUserPassword().equals(userData.getUserPassword())){
				return true;
			}
		}
		
		return false;
	}

}
