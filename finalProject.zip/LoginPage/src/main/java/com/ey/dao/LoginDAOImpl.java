package com.ey.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Optional;

import org.modelmapper.ModelMapper;

import com.ey.entity.UserEntity;
import com.ey.model.UserModel;
import com.ey.repository.LoginRepository;

@Repository
public class LoginDAOImpl implements LoginDAO{

	@Autowired
	private LoginRepository loginRepository;
	
	
	private ModelMapper mapper = new ModelMapper();
	
	
	@Override
	public UserModel checkUsernameandPassword(UserModel userData) {
				
		UserEntity UserEntity = mapper.map(userData, UserEntity.class);
		
		Optional<com.ey.entity.UserEntity> responce = loginRepository.findById(UserEntity.getCustomerID());
		
		
		UserModel model = mapper.map(responce, UserModel.class);
		
		System.out.println("model cheking" + model);
		return model;
	}

	
	
}
