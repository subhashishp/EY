package com.ey.dao;

import java.util.Optional;

import com.ey.entity.UserEntity;
import com.ey.model.UserModel;

public interface LoginDAO {

	UserModel checkUsernameandPassword(UserModel userData);
}
