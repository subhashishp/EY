package com.subhashish.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(url = "http://localhost:1112", value="BeneficiaryID")
public interface CheckBeneficiary {

	@GetMapping("/beneficiaries/byaccountnumber/{accountnumber}")
	public boolean getBeneficiary(@PathVariable Integer accountnumber);
}
