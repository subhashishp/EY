package com.subhashish.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FundTransferService{
	
	@Autowired
	private CheckBeneficiary beneficiary;
	
	public Boolean checkBeneficiary(Integer accountnumber)
	{
		
		return beneficiary.getBeneficiary(accountnumber);
		
	}

}
