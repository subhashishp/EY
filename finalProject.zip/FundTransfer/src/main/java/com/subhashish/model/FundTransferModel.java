package com.subhashish.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FundTransferModel {

	private Integer accountNumber;
	private Integer destinationAccountNumber;
	private Integer amount;
	
}
