package com.subhashish.controller;

import org.springframework.web.bind.annotation.RestController;

import com.subhashish.model.FundTransferModel;
import com.subhashish.service.FundTransferService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;


@RestController
@RequestMapping("fundtransfer")
@CrossOrigin
public class FundTransferController {

	@Autowired
	private FundTransferService fundTransferService;
	
	@PostMapping("validation")
	public Boolean postMethodName(@RequestBody FundTransferModel data) {
		return fundTransferService.checkBeneficiary(data.getDestinationAccountNumber());
		
	}
	
	
}
