package com.subhashish.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.subhashish.dao.ProfilePasswordDao;
import com.subhashish.entity.ProfilePasswordEntity;
import com.subhashish.model.ProfilePasswordModel;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("profilepasswordcheck")
@CrossOrigin
public class ProfilePasswordController {

	@Autowired
	private ProfilePasswordDao passwordDao;
	
	@PostMapping
	public Boolean postMethodName(@RequestBody ProfilePasswordModel data) {
		
		 ProfilePasswordModel tempModel = passwordDao.getProfilePassword(data.getCustomerID());
		 
		 if(tempModel != null)
		 {
			 if(tempModel.getProfilePassword().equals(data.getProfilePassword()))
			 {
				 System.out.println("same password");
				 return true;
			 }
		 }
		 
		 return false;
	}
	
	
}
