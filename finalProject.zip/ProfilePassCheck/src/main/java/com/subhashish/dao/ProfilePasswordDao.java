package com.subhashish.dao;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.subhashish.entity.ProfilePasswordEntity;
import com.subhashish.model.ProfilePasswordModel;
import com.subhashish.repository.ProfilePasswordRepositoy;

@Component
public class ProfilePasswordDao {

	@Autowired
	private ProfilePasswordRepositoy passwordRepositoy;
	
	
	private ModelMapper mapper = new ModelMapper();
	
	public ProfilePasswordModel getProfilePassword(Integer customeID)
	{
		Optional<ProfilePasswordEntity> entity = passwordRepositoy.findById(customeID);
		//System.out.println("in enitty " + entity.toString());
		ProfilePasswordModel tempModel =  mapper.map(entity, ProfilePasswordModel.class);
		//System.out.println("temp Model " + tempModel);
		return tempModel;
	}
}
