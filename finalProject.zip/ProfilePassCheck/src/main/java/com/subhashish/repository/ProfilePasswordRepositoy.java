package com.subhashish.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.subhashish.entity.ProfilePasswordEntity;


@Repository
public interface ProfilePasswordRepositoy extends JpaRepository<ProfilePasswordEntity, Integer>{

}
