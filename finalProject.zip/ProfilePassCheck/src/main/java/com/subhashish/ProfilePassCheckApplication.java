package com.subhashish;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProfilePassCheckApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProfilePassCheckApplication.class, args);
	}

}
