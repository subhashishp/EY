package com.subhashish;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProfilePassCheckApplicationTests {

	@Test
	void contextLoads() {
	}

}
