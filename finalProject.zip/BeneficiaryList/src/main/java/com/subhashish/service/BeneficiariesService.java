package com.subhashish.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.subhashish.entity.BeneficiaryEntity;
import com.subhashish.model.BeneficiaryModel;

@Service
public interface BeneficiariesService {

	public List<BeneficiaryEntity> getAll();
	public Boolean AddBeneficiary(BeneficiaryModel beneficiaryData);
	public Boolean getAccountNumber(Integer accountNumber);
	
}
