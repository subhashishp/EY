package com.subhashish.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.subhashish.dao.BeneficiariesDao;
import com.subhashish.entity.BeneficiaryEntity;
import com.subhashish.model.BeneficiaryModel;

@Service
public class BeneficiaryServiceImpl implements BeneficiariesService{
	
	@Autowired
	private BeneficiariesDao beneficiariesDao;
	
	
	@Override
	public List<BeneficiaryEntity> getAll()
	{
		return beneficiariesDao.getAll();
	}

	@Override
	public Boolean AddBeneficiary(BeneficiaryModel beneficiaryData) {
		if(beneficiariesDao.addBeneficiary(beneficiaryData) != null)
		{
			return true;
		}
		return false;
	}

	@Override
	public Boolean getAccountNumber(Integer accountNumber) {
		
		return beneficiariesDao.getAccountNumber(accountNumber);
	}
}
