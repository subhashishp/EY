package com.subhashish.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.subhashish.entity.BeneficiaryEntity;
import com.subhashish.model.BeneficiaryModel;
import com.subhashish.service.BeneficiariesService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;



@RestController
@RequestMapping("beneficiaries")
@CrossOrigin
public class BeneficiaryController {
	
	@Autowired
	private BeneficiariesService beneficiariesService; 
	
	@GetMapping("/list")
	public List<BeneficiaryEntity> getBeneficiaries() {
		return beneficiariesService.getAll();
	}
	
	@GetMapping("/byaccountnumber/{accountnumber}")
	public Boolean getAccountNumber(@PathVariable Integer accountnumber)
	{
		return beneficiariesService.getAccountNumber(accountnumber);
	}
	
	@PostMapping("/add")
	public Boolean postMethodName(@RequestBody BeneficiaryModel beneficiaryData) {
		return beneficiariesService.AddBeneficiary(beneficiaryData);
	}
}
