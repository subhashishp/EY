package com.subhashish.dao;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.subhashish.entity.BeneficiaryEntity;
import com.subhashish.model.BeneficiaryModel;
import com.subhashish.repository.BeneficiaryRepository;

@Component
public class BeneficiariesDaoImpl implements BeneficiariesDao{

	@Autowired
	private BeneficiaryRepository beneficiaryRepository;
	
	@Autowired
	private ModelMapper mapper;
	
	
	@Override
	public List<BeneficiaryEntity> getAll()
	{
		List<BeneficiaryEntity> beneficiariesList = beneficiaryRepository.findAll();
		return beneficiariesList;
	}

	@Override
	public BeneficiaryEntity addBeneficiary(BeneficiaryModel beneficiaryModel) {
		
		BeneficiaryEntity beneficiaryEntity = mapper.map(beneficiaryModel, BeneficiaryEntity.class);
		return beneficiaryRepository.save(beneficiaryEntity);
	}

	@Override
	public boolean getAccountNumber(Integer accountNumber) {
		
//		System.out.println("Checking this API");
//		System.out.println(beneficiaryRepository.findByBeneficiaryAccountNumber(accountNumber));
		if(beneficiaryRepository.findByBeneficiaryAccountNumber(accountNumber).size() != 0)
			return true;

		return false;
	}
	
	
}
