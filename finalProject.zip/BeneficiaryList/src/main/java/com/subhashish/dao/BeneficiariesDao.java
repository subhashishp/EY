package com.subhashish.dao;

import java.util.List;

import org.springframework.stereotype.Service;

import com.subhashish.entity.BeneficiaryEntity;
import com.subhashish.model.BeneficiaryModel;


public interface BeneficiariesDao {

	public List<BeneficiaryEntity> getAll();
	public BeneficiaryEntity addBeneficiary(BeneficiaryModel beneficiaryModel);
	public boolean getAccountNumber(Integer accountNumber);
}
