package com.subhashish.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.subhashish.entity.BeneficiaryEntity;
import java.util.List;


@Repository
public interface BeneficiaryRepository extends JpaRepository<BeneficiaryEntity, Integer>{

	List<BeneficiaryEntity> findByBeneficiaryAccountNumber(Integer beneficiaryAccountNumber);
}
