package com.subhashish;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeneficiaryListApplication {

	public static void main(String[] args) {
		SpringApplication.run(BeneficiaryListApplication.class, args);
	}

}
