import React from "react";
 
function BeneficiaryList() {
  return (
    <div>
      <h2>Beneficiary List</h2>
      <table>
        <thead>
          <tr>
            <td>Beneficiary Account Number</td>
            <td>Account type</td>
            <td>IFSC Code</td>
            <td>Beneficiary Name</td>
            <td>Email Id</td>
            <td>Status</td>
          </tr>
        </thead>
        <tbody>
          {/* {mockAcc.map((account, index) => (
            <tr key={index}>
              <td>{account.accountNumber}</td>
              <td>{account.branchName}</td>
              <td>{account.customerName}</td>
              <td>{account.availableBalance}</td>
            </tr>
          ))} */}
        </tbody>
      </table>
    </div>
  );
}
 
export default BeneficiaryList;