import React from 'react'
import { useState } from 'react';

export default function AddBeneficiary() {

    const [beneficiaryID, setBeneficiaryMessage] = useState("");
    const [customerID, setConstomerID] = useState("");
    const [accountNumber, setSetAccountNumber] = useState("");
    const [IFSC, setIFSC] = useState("");
    const [accountType, setaccountType] = useState("");
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");

    const handleSubmit = (event) => {
        event.preventDefault(); // Prevent the default form submission
        console.log('Beneficiary ID:', beneficiaryID);
        console.log('Customer ID:', customerID);
        console.log('Account Number:', accountNumber);
        console.log('IFSC Code:', IFSC);
        console.log('Account Type:', accountType);
        console.log('Name:', name);
        console.log('Email:', email);
    }


    return (
    <div>
      <form onSubmit={handleSubmit} action="">
        <input type="text" placeholder='Beneficiary ID' onChange={e => setBeneficiaryMessage(e.target.value)} required/> 
        <input type="text" placeholder='Customer ID' onChange={e => setConstomerID(e.target.value)} required/> 
        <input type="number" placeholder='Account Number' onChange={e => setSetAccountNumber(e.target.value)} required/> 
        <input type="text" placeholder="IFCS Code" onChange={e => setIFSC(e.target.value)} required/> <br />
        <input type="text" placeholder='Account Type' onChange={e => setaccountType(e.target.value)} required/> 
        <input type="text" placeholder='Name' onChange={e => setName(e.target.value)} required/> 
        <input type="email" placeholder='email-id' onChange={e => setEmail(e.target.value)} required/> <br />
        <button type="submit">Submit</button>
      </form>
    </div>
  )
}
