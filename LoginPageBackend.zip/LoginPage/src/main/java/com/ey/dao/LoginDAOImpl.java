package com.ey.dao;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.Optional;

import org.modelmapper.ModelMapper;

import com.ey.entity.UserEntity;
import com.ey.model.UserModel;
import com.ey.repository.LoginRepository;

public class LoginDAOImpl implements LoginDAO{

	private LoginRepository loginRepository;
	
	@Autowired
	private ModelMapper mapper;
	
	
	@Override
	public UserModel checkUsernameandPassword(UserModel userData) {
				
		UserEntity UserEntity = mapper.map(userData, UserEntity.class);
		
		Optional<com.ey.entity.UserEntity> responce = loginRepository.findById(UserEntity.getUserName());
		
		UserModel model = mapper.map(responce, UserModel.class);
		
		return model;
	}

	
	
}
