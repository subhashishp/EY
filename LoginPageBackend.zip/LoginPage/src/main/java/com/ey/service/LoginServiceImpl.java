package com.ey.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.ey.dao.LoginDAO;
import com.ey.entity.UserEntity;
import com.ey.model.UserModel;

@Service
public class LoginServiceImpl implements LoginService{

	private LoginDAO dao; 
	
	@Override
	public Boolean checkUsernameandPassword(UserModel userData) {
		
		
		UserModel tempModel = dao.checkUsernameandPassword(userData);
		
		// do password check
		
		//tempModel contains database data
		//userData contains the data from user (controller)
		
		if(tempModel.getPassword().equals(userData.getPassword())){
			return true;
		}
		
		return false;
	}

}
