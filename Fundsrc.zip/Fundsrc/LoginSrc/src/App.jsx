import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <div>
        <h1>Login Form</h1>
        
        <div class="login">
         <img src="assets/img/login-bg.png" alt="image" class="login__bg">

         <form action="" class="login__form">
            <h1 class="login__title">Login</h1>

            <div class="login__inputs">
               <div class="login__box">
                  <input type="number" placeholder="User ID" required class="login__input">
               </div>

               <div class="login__box">
                  <input type="password" placeholder="Password" required class="login__input">
               </div>
            </div>

            <div class="login__check">
               <div class="login__check-box">
                  <input type="checkbox" class="login__check-input" id="user-check">
                  <label for="user-check" class="login__check-label">Remember me</label>
               </div>

               <a href="#" class="login__forgot">Forgot Password?</a>
            </div>

            <button type="submit" class="login__button">Login</button>

            <div class="login__register">
               Don't have an account? <a href="signUp.html">Register</a>
            </div>
         </form>
        </div>

      </div>
    </>
  )
}

export default App
