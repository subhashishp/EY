import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [Amount, setAmount] = useState(0);
  const [sourceAccountNumber, setsourceAccountNumber] = useState(0);
  const [destinationAccountNumber, setdestinationAccountNumber] = useState(0);


  const validateAccountNumbers = (e) => {
    e.preventDefault(); // Prevent the default form submission

    //write fetch (post) to send the data in backend
    //check details in backend if present in beneficiary re-route to profile-password check

    console.log('Amount:', Amount);
    console.log('Source account number:', sourceAccountNumber);
    console.log('Destination account number:', destinationAccountNumber);
}

  return (
    <>
      <div>
        <h1>Fund Transfer</h1>
        <form onSubmit={validateAccountNumbers} action="">
          <input type="number" placeholder='Amount' onChange={e => setAmount(e.target.value)} required/>
          <input type="number" placeholder='Source Account Number' onChange={e => setsourceAccountNumber(e.target.value)} required/>
          <input type="number" placeholder='Destination Account Number' onChange={e => setdestinationAccountNumber(e.target.value)} required/> <br />
          <button type="submit">Validate</button>
        </form>
      </div>
    </>
  )
}

export default App
